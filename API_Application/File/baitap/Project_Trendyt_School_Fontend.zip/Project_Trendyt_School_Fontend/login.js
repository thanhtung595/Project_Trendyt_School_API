document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Lấy giá trị từ các trường input
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const dataToSend = {
        user_Name: username,
        user_Password: password
    };

    // Gọi API bằng phương thức Fetch
    fetch('http://103.252.94.68/api/v1/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(dataToSend)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        // Xử lý dữ liệu trả về từ API (ví dụ: kiểm tra kết quả đăng nhập)
        console.log(data);
        // Redirect hoặc thực hiện hành động phù hợp sau khi đăng nhập thành công
    })
    .catch(error => {
        // Xử lý lỗi
        console.error('There was a problem with your fetch operation:', error);
    });
});